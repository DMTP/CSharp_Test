﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question4
{
    class Program
    {
        static void Main(string[] args)
        {
            int total = 0;
            for (int i = 0, count = 0; count < 59; i++)
            {
                if (CheckPrime(i) == true)
                {
                    total += i;
                }
            }
            Console.Write(total);
            Console.ReadKey();
        }
        static bool CheckPrime(int value)
        {
            bool result = true;
            for (int i = 2; i < value; i++)
            {
                if (value % i == 0)
                {
                    result = false;
                }
            }
            if (value <= 1)
                result = false;
            return result;
        }
    }
}