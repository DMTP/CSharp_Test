﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            string givenSentence = "Please replace all characters equals to the letter 'A' with an underscore (_)";
            givenSentence = Regex.Replace(givenSentence, "[Aa]", "_");
            Console.WriteLine(givenSentence);
            Console.ReadKey();
        }
    }
}
