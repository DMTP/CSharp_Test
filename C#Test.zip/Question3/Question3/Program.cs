﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Question3
{
    class Program
    {
        static void Main(string[] args)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = "Server=[(localdb)];Database=[localdb];Trusted_Connection=true";
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Users WHERE Branch = 'Johannesburg' AND Shift = 'Half day';", conn);
                Console.Write(cmd.ToString());
                Console.ReadLine();
                conn.Close();
            }
        }
    }
}